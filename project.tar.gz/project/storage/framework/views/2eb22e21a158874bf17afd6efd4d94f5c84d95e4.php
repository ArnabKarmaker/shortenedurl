<div class="container">
    <h1>Shorten Your Link</h1>
   
    <div class="card">
      <div class="card-header">
         
            <meta name="csrf-token" content="<?php echo csrf_token(); ?>">
            <div class="input-group mb-12">
             
              <input type="text" name="link" class="form-control longurl" placeholder="Enter URL" aria-label="Recipient's username" aria-describedby="basic-addon2">

             
              
                <button class="btn btn-success button" type="submit">Generate Shorten Link</button>
                <p><a href="" target="_blank"></a></p>

              
            </div>
    
      </div>
     
    </div>
   
</div>
<script src= 
"https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> 
    </script> 

<script>
    $("button").click(function(){

        $(".longurl").css('border-color', '');

        var long_url=$(".longurl").val();
        var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
        var token=$('meta[name="csrf-token"]').attr('content');



    

     if(regexp.test(long_url)){ 
    
        $.ajax({
          url: '/urlsubmit',
          type: 'post',
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          data : { long_url : long_url},
          
         
          success: function(data) {

            $("a").attr("href", data);
            $("a").text(data);
            
          }
        });
       }
       else
       {
        $(".longurl").css('border-color', 'red');
       }

  });


</script>