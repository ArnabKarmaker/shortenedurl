<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mymodel extends Model
{
	protected $table = "short_links";
     protected $fillable = [
        'code', 'link'
    ];
}
