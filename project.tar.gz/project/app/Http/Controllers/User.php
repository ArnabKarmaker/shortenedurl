<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;


use App\UserRegistration as fetchdataregistration;

class User extends BaseController
{
    public function registration()
    {
    	return view("register");
    }



    public function insertdata(Request $request)
    {


        $Registration = new UserRegistration;
        $Registration->username = $request->Input('name');
        $Registration->email = $request->Input('email');
        //$Registration->password = $request->Input('password');
        $Registration->save();
    }
    public function fetchdata(Request $request)
    {

       //$result = fetchdataregistration::where('id', 1)->first();

       $result = fetchdataregistration::find(1)->id;
       

       //$result = App\UserRegistration::where('id', 1)->first();
       echo "<pre>";
       print_r($result);die;


    }
}
