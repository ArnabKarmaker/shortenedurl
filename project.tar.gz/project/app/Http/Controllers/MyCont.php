<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;


use App\Mymodel;

class MyCont extends BaseController
{
    public function index()
    {
    	return view("view");
    }



    public function makeshortUrl(Request $request)
    {
      



        $input['link'] = $request->input('long_url');
        $input['code'] = str_random(6);

       

        $find = Mymodel::where('link',$input['link'])->first();
        //print_r($find); die;


        if($find!==null)
        {
            $code=$find->code;
        }
        else
        {
          Mymodel::create($input);
           $code=$input['code'];
          
        }
   
       

        echo $code;


       
    }
    public function shortenLink($code)
    {

       $find = Mymodel::where('code', $code)->first();
        return redirect($find->link);


    }
}
